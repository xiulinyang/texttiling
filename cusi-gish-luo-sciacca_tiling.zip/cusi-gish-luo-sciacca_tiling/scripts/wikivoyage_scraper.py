# used ChatGPT for steps on how to create a basic webscraper

import requests
from bs4 import BeautifulSoup
import stanza
import pandas as pd
from urllib.parse import urlparse

# URL of WikiVoyage page
url = "https://en.wikivoyage.org/wiki/Rio_de_Janeiro"

parsed_url = urlparse(url)
city_name = parsed_url.path.split("/")[-1]

response = requests.get(url)

if response.status_code == 200:
    pass
else:
    print(f"Error: Unable to retrieve content from {url}")
    exit()


soup = BeautifulSoup(response.content, 'html.parser')

paragraphs = soup.find_all('p')

with open(f'{city_name}.txt', 'w', encoding='utf-8') as file:
    for paragraph in paragraphs:
        file.write(paragraph.get_text() + '\n')


# stanza.download('en')
nlp = stanza.Pipeline('en')

f = open(f"{city_name}.txt", "r")
text = f.read()

doc = nlp(text)
sentences_list = [sentence.text for sentence in doc.sentences]

# save data into DF --> export as excel sheet
df = pd.DataFrame({"Sentence": sentences_list})
excel_file_path = f"{city_name}.xlsx"
df.to_excel(excel_file_path, index=False)

print(f"Excel file has been created: {excel_file_path}")

