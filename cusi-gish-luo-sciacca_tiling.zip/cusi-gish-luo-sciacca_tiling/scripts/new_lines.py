# Convert text files into rows of excel sheets, with each row being a full sentence

import re
import pandas as pd


# CHANGE VARS HERE
filename = "vlog5_great-news-about-layla"


input_file = f"{filename}.txt"
output_file = f"{filename}.xlsx"

with open(input_file, "r", encoding="utf-8") as input_file:
    text = input_file.read()

    lines = text.split('\n')

    # Combine lines that do not end with . or ? or !
    combined_lines = []
    current_line = ""

    for line in lines:
        line = line.strip()
        
        if line and not line.endswith(('.', '?', '!')):
            current_line += ' ' + line
        else:
            combined_lines.append(current_line + " " + line)
            current_line = ""

    # Output the combined lines
    # for line in combined_lines:
    #     print(line)

df = pd.DataFrame({'Sentence': combined_lines})

# Save the DataFrame to a text (txt) file
df.to_excel(output_file, index=False)

